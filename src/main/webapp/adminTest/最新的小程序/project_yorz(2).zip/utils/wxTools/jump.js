
const Jump = {
  home: function () {
    return "首页"
  },
  list: function () {
    return "列表页"
  },
  detail: function () {
    return "详情页"
  },
  page: function () {
    return "单页"
  }

}

module.exports = Jump
